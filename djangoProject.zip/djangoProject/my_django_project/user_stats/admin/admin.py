from django.contrib import admin
from user_stats.models import UserStatsMain

@admin.register(UserStatsMain)
class UserStatsMainAdmin(admin.ModelAdmin):
    list_display = ('user_id', 'total_attempts', 'successful_attempts', 'total_puzzles_solved')  # Поля для відображення в списку
    list_filter = ('user_id',)  # Фільтр за полем користувача
    search_fields = ('user_id__user_name',)  # Пошук за ім'ям користувача
    ordering = ('-total_puzzles_solved',)  # Сортування за кількістю вирішених пазлів у спадному порядку
