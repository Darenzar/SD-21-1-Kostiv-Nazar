from django.db import models

class UserStatsMain(models.Model):
    user_id = models.ForeignKey('Puzzle', on_delete=models.CASCADE)
    total_attempts = models.IntegerField()
    successful_attempts = models.IntegerField()
    total_puzzles_solved = models.IntegerField()

    'user_id','total_attempts','successful_attempts','total_puzzles_solved'