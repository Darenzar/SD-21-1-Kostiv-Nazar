from rest_framework import serializers
from .models import UserStatsMain

class UserStatsMainSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserStatsMain
        fields = 'user_id','total_attempts','successful_attempts','total_puzzles_solved'
