from django.contrib import admin
from ratings.models import RatingMain

@admin.register(RatingMain)
class RatingMainAdmin(admin.ModelAdmin):
    list_display = ('rating_id', 'puzzle_id', 'user_id', 'rating_value')  # Поля для відображення в списку
    list_filter = ('puzzle', 'rating_value')  # Фільтри за пазлом і значенням рейтингу
    search_fields = ('puzzle__title', 'user__username')  # Пошук за назвою пазла і користувачем
    ordering = ('-rating_value',)  # Сортування за значенням рейтингу у спадному порядку
