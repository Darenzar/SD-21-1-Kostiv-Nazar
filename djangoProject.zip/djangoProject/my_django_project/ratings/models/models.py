from django.db import models

class RatingMain(models.Model):
    rating_id = models.AutoField(primary_key=True)
    puzzle_id = models.ForeignKey('Puzzle', on_delete=models.CASCADE)
    user_id = models.ForeignKey('User', on_delete=models.CASCADE)
    rating_value = models.IntegerField()

    'rating_id', 'puzzle_id', 'user_id', 'rating_value'