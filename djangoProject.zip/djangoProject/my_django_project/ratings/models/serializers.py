from rest_framework import serializers
from .models import RatingMain

class RatingMainSerializer(serializers.ModelSerializer):
    class Meta:
        model = RatingMain
        fields = 'rating_id', 'puzzle_id', 'user_id', 'rating_value'
