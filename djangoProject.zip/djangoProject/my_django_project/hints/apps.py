from django.apps import AppConfig


class HintsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hints'
