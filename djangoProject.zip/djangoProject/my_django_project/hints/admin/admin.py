from django.contrib import admin
from hints.models import HintsAdmin

@admin.register(HintsAdmin)
class HintsAdmin(admin.ModelAdmin):
    list_display = ('hints_id', 'puzzle_id', 'hint_text', 'hint_order')
    list_filter = ('puzzle',)
    search_fields = ('puzzle__title', 'hint_text')
    ordering = ('hint_order',)
