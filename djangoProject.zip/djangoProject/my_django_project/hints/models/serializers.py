from rest_framework import serializers
from .models import HintsMain

class HintsMainSerializer(serializers.ModelSerializer):
    class Meta:
        model = HintsMain
        fields = ['hints_id','puzzle_id','hint_text','hint_order']  # Включає всі поля моделі
