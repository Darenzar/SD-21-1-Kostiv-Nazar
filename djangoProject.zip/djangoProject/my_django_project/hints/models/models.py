from django.db import models

class HintsMain(models.Model):
    hints_id = models.AutoField(primary_key=True)
    puzzle_id = models.ForeignKey('Puzzle', on_delete=models.CASCADE)
    hint_text = models.TextField()
    hint_order = models.IntegerField()

    'hints_id','puzzle_id','hint_text','hint_order'