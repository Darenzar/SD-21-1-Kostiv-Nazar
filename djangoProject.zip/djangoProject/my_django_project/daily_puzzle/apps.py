from django.apps import AppConfig


class DailyPuzzleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'daily_puzzle'
