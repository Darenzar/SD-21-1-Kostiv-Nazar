from django.contrib import admin
from daily_puzzle.models import DailyPuzzleMain

@admin.register(DailyPuzzleMain)
class DailyPuzzleAdmin(admin.ModelAdmin):
    list_display = ('daily_puzzle_id', 'puzzle', 'date')  # Поля, які відображатимуться в списку
    list_filter = ('date',)  # Фільтр за датою
    search_fields = ('puzzle__title',)  # Пошук за назвою пазла
    ordering = ('-date',)  # Сортування за датою (новіші записи зверху)
