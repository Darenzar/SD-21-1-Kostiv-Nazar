from rest_framework import serializers
from my_django_project.daily_puzzle.models.models import DailyPuzzle

class DailyPuzzleSerializer(serializers.ModelSerializer):
    class Meta:
        model = DailyPuzzle
        fields = ['daily_puzzle_id', 'puzzle_id', 'date']

