from rest_framework import serializers
from .models import PuzzleMain

class PuzzleMainSerializer(serializers.ModelSerializer):
    class Meta:
        model = PuzzleMain
        fields = 'puzzle_id','title','description','encoded_text','shift_value'