from django.contrib import admin
from Puzzles.models import PuzzleMain

@admin.register(PuzzleMain)
class PuzzleAdmin(admin.ModelAdmin):
    list_display = ('puzzle_id', 'title', 'encoded_text', 'shift_value')  # Поля, які будуть відображатися у списку
    list_filter = ('shift_value',)  # Фільтр по полю shift_value
    search_fields = ('title', 'description')  # Поля для пошуку
    ordering = ('puzzle_id',)  # Сортування за puzzle_id
