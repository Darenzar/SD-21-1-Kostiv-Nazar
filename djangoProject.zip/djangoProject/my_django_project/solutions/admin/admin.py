from django.contrib import admin
from solutions.models import SolutionMain

@admin.register(SolutionMain)
class SolutionMainAdmin(admin.ModelAdmin):
    list_display = ('solution_id', 'puzzle_id', 'user_id', 'is_correct', 'attempted_at')  # Поля для відображення в списку
    list_filter = ('is_correct', 'attempted_at')  # Фільтри за полем правильності та датою
    search_fields = ('puzzle__title', 'user__username', 'solution_text')  # Пошук за назвою пазла, ім'ям користувача і текстом рішення
    ordering = ('-attempted_at',)  # Сортування за датою спроби (новіші зверху)
