from django.db import models

class SolutionMain(models.Model):
    solution_id = models.AutoField(primary_key=True)
    puzzle_id = models.ForeignKey('Puzzle', on_delete=models.CASCADE)
    user_id = models.ForeignKey('User', on_delete=models.CASCADE)
    solution_text = models.TextField()
    is_correct = models.BooleanField()
    attempted_at = models.DateTimeField()


    'solution_id', 'user_id', 'puzzle_id', 'solution_text', 'is_correct', 'attempted_at'