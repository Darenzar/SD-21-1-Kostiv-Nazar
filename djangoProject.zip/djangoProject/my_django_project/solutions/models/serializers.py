from rest_framework import serializers
from .models import SolutionMain

class SolutionMainSerializer(serializers.ModelSerializer):
    class Meta:
        model = SolutionMain
        fields = 'solution_id', 'user_id', 'puzzle_id', 'solution_text', 'is_correct', 'attempted_at'