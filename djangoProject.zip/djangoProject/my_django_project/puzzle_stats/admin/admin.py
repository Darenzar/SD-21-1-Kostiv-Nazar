from django.contrib import admin
from .models import PuzzleStatsMain

@admin.register(PuzzleStatsMain)
class PuzzleStatsMainAdmin(admin.ModelAdmin):
    list_display = ('puzzle_id', 'average_rating', 'total_attempts', 'successful_attempts')  # Поля, які відображаються в списку
    list_filter = ('puzzle',)  # Фільтр за полем puzzle
    search_fields = ('puzzle__title',)  # Пошук за назвою пазла
    ordering = ('-average_rating',)  # Сортування за середнім рейтингом у спадному порядку
