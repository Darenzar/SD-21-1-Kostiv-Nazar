from django.db import models

class PuzzleStatsMain(models.Model):
    puzzle_id = models.ForeignKey('Puzzle', on_delete=models.CASCADE)
    average_rating = models.FloatField()
    total_attempts = models.IntegerField()
    successful_attempts = models.IntegerField()

    'puzzle_id', 'average_rating', 'total_attempts', 'successful_attempts'