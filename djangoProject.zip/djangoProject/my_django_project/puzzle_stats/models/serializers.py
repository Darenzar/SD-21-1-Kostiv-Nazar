from rest_framework import serializers
from .models import PuzzleStatsMain

class PuzzleStatsMainSerializer(serializers.ModelSerializer):
    class Meta:
        model = PuzzleStatsMain
        fields =  'puzzle_id', 'average_rating', 'total_attempts', 'successful_attempts'