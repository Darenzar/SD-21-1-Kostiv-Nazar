from django.contrib import admin
from User.models import UserMain

@admin.register(UserMain)
class UserMainAdmin(admin.ModelAdmin):
    list_display = ('user_id', 'user_name', 'email', 'created_at')  # Поля для відображення в списку
    list_filter = ('created_at',)  # Фільтр за датою створення
    search_fields = ('user_name', 'email')  # Пошук за ім'ям користувача та електронною поштою
    ordering = ('-created_at',)  # Сортування за датою створення у спадному порядку
