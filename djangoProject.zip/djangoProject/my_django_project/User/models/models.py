from django.db import models

class UserMain(models.Model):
    user_id = models.AutoField(primary_key=True)  # Унікальний ідентифікатор користувача
    user_name = models.CharField(max_length=50)  # Ім'я користувача
    email = models.CharField(max_length=50)  # Електронна пошта користувача
    password_hash = models.CharField(max_length=50)  # Хеш паролю користувача
    created_at = models.DateTimeField(auto_now_add=True)  # Дата і час створення користувача

'user_id','user_name','email','password_hash','created_at'