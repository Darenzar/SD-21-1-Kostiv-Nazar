from rest_framework import serializers
from .models import UserMain

class UserMainSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserMain
        fields = 'user_id','user_name','email','password_hash','created_at'
        extra_kwargs = {
            'password_hash': {'write_only': True}  # Приховуємо поле паролю у відповіді API
        }
