from rest_framework import serializers
from my_django_project.attempts.models.models import Attempt

class AttemptSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attempt
        fields = ['id', 'puzzle_id', 'user_id', 'attempt_text', 'is_successful', 'attempted_at']