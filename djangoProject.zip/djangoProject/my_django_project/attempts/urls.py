from django.urls import path
from my_django_project.attempts.api.views import AttemptList, AttemptRetrieve, AttemptCreate, AttemptUpdate, AttemptDestroy


urlpatterns = [
    path('v1/games/', AttemptList.as_view(), name='game-list'),
    path('v1/games/<int:pk>/', AttemptRetrieve.as_view(), name='game-detail'),
    path('v1/games/create/', AttemptCreate.as_view(), name='game-create'),
    path('v1/games/<int:pk>/update/', AttemptUpdate.as_view(), name='game-update'),
    path('v1/games/<int:pk>/delete/', AttemptDestroy.as_view(), name='game-destroy'),
]