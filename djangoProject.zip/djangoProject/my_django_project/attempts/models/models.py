from django.db import models
from django.contrib.auth.models import User

class Attempt(models.Model):
    puzzle_id = models.ForeignKey('Puzzle', on_delete=models.CASCADE)
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    attempt_text = models.TextField()
    is_successful = models.BooleanField()
    attempted_at = models.DateTimeField()

    def __str__(self):
        return self.attempt_text